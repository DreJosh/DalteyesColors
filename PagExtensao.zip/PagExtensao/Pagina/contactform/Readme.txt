Anotações do site
